# DODGE THE CREEPS - README


Installation:
------------------------------
1. Udpak ZIP-filen til en valgfri mappe.
2. Sørg for at filen "DodgeTheCreeps.exe" og mappen 
   "data_Dodge the Creeps_windows_x86_64" ligger i samme mappe.
   Eksempel:
      DodgeTheCreeps/
        ├─ DodgeTheCreeps.exe
        └─ data_Dodge the Creeps_windows_x86_64/

Sådan spiller du:
------------------------------
- Dobbeltklik på "DodgeTheCreeps.exe" for at starte spillet.
- Brug piletasterne eller WASD til at bevæge dig.
- Undgå fjenderne så længe du kan for at få en høj score!

Tips:
------------------------------
- Hvis spillet ikke starter, så prøv at højreklikke på
  "DodgeTheCreeps.exe" og vælg "Kør som administrator".
- Du kan også tjekke, at du har de nyeste .NET runtime-filer
  installeret (kræves kun i visse Windows-versioner).

Kontakt:
------------------------------
Udviklet af: Gustav Færmann Lassen (Som følge af Godot's egen 2D tortorial)
Version: 1.0
Godot 4.5 (C# version)

Tak fordi du prøver mit spil
